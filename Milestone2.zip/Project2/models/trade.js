const _ = require('lodash');
const { v4: uuidv4 } = require('uuid')

const categories = ["Automatic","Smart Watch","Digital","Analog"];

const tradeList = [
    {   
        id: "1",
        category: 'Automatic',
        categoryid: '0',
        name: "Tissot Couturier Automatic Chronograph",
        color: "black",
        description: `Just as the creations of the world's great fashion designers rely on the perfect mix of fabric and cut, 
        the Tissot Couturier timepieces blend elegant lines with materials to match. These watches express their made-to-measure character 
        through their uncompromising attention to detail. 
        These promise to outlive any fashion whim and stand the test of time.`,
        brand : 'Tissot',
        image:'/images/tissot_automatic.png'
    },
    {   
        id: "2",
        category: 'Automatic',
        color: "red",
        categoryid: '0',
        name: "Tissot PRS 516 Automatic Chronograph",
        description: `The PRS 516 is simply the most prestigious sports watch within the Tissot collection. 
        This timepiece dates back to 1965, featuring design details inspired by classic sports 
        cars including a perforated bracelet and piston-shaped pushers. The PRS 516 is truly a pioneer watch that will never go out
         of style.`,
        brand : 'Tissot',
        image:'/images/tissot2_automatic.png'
    },
    {   
        id: "3",
        category: 'Automatic',
        categoryid: '0',
        color: "blue",
        name: "Tag Heuer Carrera X Porsche Orange Racing",
        description: `Speed is the name of the game in this TAG Heuer Carrera Porsche Special Edition. 
        Paying tribute to the passion for racing shared by TAG Heuer and Porsche, 
        it distills a bright orange inspired by the color of the sparks of heat made by the car on the asphalt. Victory is on the horizon.`,
        brand : 'Tag Heuer',
        image:'/images/tagheuer_automatic.png'
    },
    {   
        id: "4",
        category: 'Smart Watch',
        categoryid: '1',
        color: "black",
        name: "Apple Watch Ultra",
        description: `The most rugged and capable Apple Watch ever, designed for exploration, adventure, and endurance. 
        With a 49mm aerospace-grade titanium case, extra-long battery life,1 specialized apps that work with the advanced sensors,
         and a new customizable Action button.`,
        brand : 'Apple',
        image:'/images/apple_watch_ultra.png'
    },
    {   
        id: "5",
        category: 'Smart Watch',
        categoryid: '1',
        color: "black",
        name: "Google Pixel Watch",
        description: `The Google Pixel Watch has a beautiful circular, domed design and new experience with Wear OS by Google, so it’s easy to get help at a glance`,
        brand : 'Google',
        image:'/images/pixel_watch.png'
    },
    {   
        id: "6",
        category: 'Smart Watch',
        categoryid: '1',
        color: "black",
        name: "Galaxy Watch5 Pro",
        description: `The Samsung Galaxy Watch5 Pro, the premium smartwatch designed to fit your lifestyle. 
        Stay ready for adventures with this durable smartwatch optimized for outdoor activity to last through your toughest days. `,
        brand : 'Samsung',
        image:'/images/samsung_galaxy.png'
    },
]

//Get all trades category wise.
exports.getTrades = () => _.groupBy(tradeList,"category");

// Get a trade by id
exports.getTradeByID = id => tradeList.find(t => t.id === id);

// Create a trade
exports.createTrade = trade => {
    trade.id = uuidv4();
    trade.image = "/images/noimage.png";
    trade.categoryid = categories.indexOf(trade.category);
    tradeList.push(trade);
}

// Update a trade by ID
exports.updateTrade = (id,newTrade) => {
    let trade = this.getTradeByID(id);
    if(trade) {
        trade.category = newTrade.category;
        trade.name = newTrade.name;
        trade.description = newTrade.description;
        trade.brand = newTrade.brand;
    }
    return trade ? true : false;
}

//Delete a trade by ID
exports.deleteTradeByID = id => {
    let i = tradeList.findIndex(t => t.id ===id);
    if(i>=0) {
        tradeList.splice(i,1);
        return true
    }
    return false;
}
