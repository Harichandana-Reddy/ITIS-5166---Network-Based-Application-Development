// Handles home page controller
exports.index = (req, res) => {
	res.render("index");
};

// Handles about page controller
exports.about = (req, res) => {
	res.render("about");
};

// Handles contact page controller
exports.contact = (req,res) => {
	res.render("contact");
}
