const trademodel = require('../models/trade');

// Controller for trades list view
exports.index = (req,res) => {
    let tradelist = trademodel.getTrades();
    res.render('./trades/trades',{tradelist});
};

// Controller for getting a trade by id
exports.getTradeByID = (req,res) => {
    let trade = trademodel.getTradeByID(req.params.id);
    if(trade) {
        res.render("./trades/trade",{trade});
    } else {
        let err = new Error('Cannot find trade with id ' +id);
        err.status = 404;
        next(err);
    }
};

//controller for getting create trade form
exports.createTradeForm = (req,res) => {
    res.render("./trades/newTrade");
}

//controller for create trade
exports.createTrade = (req,res) => {
   let trade = req.body;
   trademodel.createTrade(trade);
   res.redirect("/trades");
}

//controller for getting edit trade form
exports.editTradeForm = (req,res) => {
    let trade = trademodel.getTradeByID(req.params.id);
    res.render("./trades/editTrade",{trade});
}

// Controller for updating trade details
exports.updateTradeDetails = (req,res) => {
    if(trademodel.updateTrade(req.params.id,req.body)) {
      res.redirect(`/trades/${req.params.id}`);
    } else {
      let err = new Error("Unable to find the trade with id:"+req.params.id);
      err.status = 404;
      next(err);
    }
}

// Controller for deleting trade
exports.deleteTrade = (req,res) => {
    console.log("dd");

  if(trademodel.deleteTradeByID(req.params.id)) {
    res.redirect("/trades");
  } else {
    let err = new Error("Unable to find the trade with id:"+req.params.id);
    err.status = 404;
    next(err);
  }
}