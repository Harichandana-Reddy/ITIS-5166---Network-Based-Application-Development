const express = require("express");
const router = express.Router();
const mainController = require("../controllers/mainController");

//GET request /: redirects to the home page
router.get("/", mainController.index);

//GET request /contact: redirects to the contact page
router.get("/contact", mainController.contact);

//Get request /about: redirects to the about page
router.get("/about", mainController.about);

module.exports = router;
