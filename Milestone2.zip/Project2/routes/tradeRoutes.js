const express = require('express');
const router = express.Router();
const controller = require('../controllers/tradeController');

//GET /: gets all trades
router.get('/', controller.index);

//GET /new gets the create trade form
router.get('/new', controller.createTradeForm);

//GET /:id gets a trade by id
router.get('/:id', controller.getTradeByID);

//POST /: creates a new trade
router.post("/",controller.createTrade);

//GET /:id/edit gets trade edit form
router.get("/:id/edit",controller.editTradeForm);

//PUT /:id/edit updates trade details
router.put("/:id/edit",controller.updateTradeDetails);

//DELETE /:id/delete deletes the trade
router.delete("/:id",controller.deleteTrade);

module.exports = router;
