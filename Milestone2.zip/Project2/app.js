// Loading the required modules
const express = require("express");
const methodOverride = require("method-override");
const morgan = require("morgan");
const mainroutes = require("./routes/mainRoutes");
const traderoutes = require("./routes/tradeRoutes");
const app = express();
app.set("view engine", "ejs");

// Code for mounting the middlewares
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
app.use(morgan("tiny"));

// Route calls
app.use("/", mainroutes);
app.use("/trades", traderoutes);

// Error Handling
app.use((req, _res, next) => {
	let err = new Error("The server cannot locate the resource" + req.url);
	err.status = 404;
	next(err);
});

app.use((err, _req, res, _next) => {
	if (!err.status) {
		err.status = 500;
		console.log(err);
		err.message = "Internal Server Error";
	}
	res.status(err.status);
	res.render("error", { error: err });
});

app.listen(3330, "localhost", () => {
	console.log("Server started running on port", 3330);
});
